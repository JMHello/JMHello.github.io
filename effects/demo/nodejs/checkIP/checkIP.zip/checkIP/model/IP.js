const dns = require('dns');
const IP = {};

IP.checkIP = (req, res) => {
 req.on('data', (data) => {
   const uri = JSON.parse(data).uri;
   dns.lookup(uri, function (err, address, family) {
     if (err) {
       res.write(JSON.stringify({
         status: false,
         info: '解析错误'
       }));
       res.end();
     } else {
       res.write(JSON.stringify({
         status: true,
         ip: address
       }));
       res.end();
     }
   })

 });
};

IP.getURI = (req, res) => {
  res.write(JSON.stringify({
    status: true,
    ip: req.socket.localAddress
  }))
  res.end();
}


module.exports = IP;