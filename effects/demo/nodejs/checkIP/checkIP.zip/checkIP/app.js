const http = require('http');
const fs = require('fs');
const IP = require('./model/IP');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;
  if (url === '/') {
   const data = fs.readFileSync('./public/index.html');
   res.write(data);
   res.end();
  } else if (url === '/checkIP_action') {
    IP.checkIP(req, res);
  } else if (url === '/getURI_action') {
    IP.getURI(req,res, http);
  }
})

server.listen(8080, '127.0.0.1');