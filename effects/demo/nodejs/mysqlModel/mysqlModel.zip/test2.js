/**
 * 1. 主要解决mysql建立连接和关闭连接的回调繁琐问题
 */
const mysql = require('mysql')

const options = {
  host: 'localhost',
  port: 3306,
  database: 'goods',
  user: 'root',
  password: 'sz1997'
}

let connection = mysql.createConnection(options);

// 建立连接
let connect = function () {
  return new Promise((resolve, reject) => {
    connection.connect((err) => {
      if (err) {
        reject(err)
      } else {
        resolve()
      }
    })
  })
}

// 关闭连接
let end = function () {
  return new Promise((resolve, reject) => {
    connection.end((err) => {
      if (err) {
        reject(err)
      } else {
        resolve()
      }
    })
  })
}

// 测试
connect().
  then(() => {
  console.log('连接数据库成功！')
  // 关键
  return end()
})
  .then(() => {
  console.log('关闭数据库成功！')
})

