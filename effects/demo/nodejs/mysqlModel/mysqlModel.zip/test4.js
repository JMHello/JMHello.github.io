/**
 * 1. 建立连接池
 */
const mysql = require('mysql')

const options = {
  host: 'localhost',
  port: 3306,
  database: 'goods',
  user: 'root',
  password: 'sz1997'
}

let pool = mysql.createPool(options);

/**
 * 建立连接池
 * @returns {Promise}
 */
let getConnection = function () {
  return new Promise((resolve, reject) => {
    pool.getConnection((err, connection) => {
      if (err) {
        reject(err)
      } else {
        resolve(connection)
      }
    })
  })
}

/**
 *
 * @param connection 连接对象
 * @param sql
 * @param parameters
 * @returns {Promise}
 */
let query = function (connection, sql, parameters) {
  return new Promise((resolve, reject) => {
    connection.query(sql, parameters, (err, results) => {
      if (err) {
        reject(err)
      } else {
        resolve(results)
      }
    }).on('end', () => {
      console.log('本次数据库操作完毕！')
      // 记得释放连接，不然后果很严重！！
      try { connection.release() } catch (e) {};
    })
  })
}

// 这里用了 es7 的语法糖：async/await
getConnection()
  .then(async (connection) => {
    const result1 = await query(connection, `SELECT * FROM list WHERE id=2`)
    const result2 = await query(connection, `SELECT * FROM list WHERE id=3`)
    console.log(result1, result2)
  })


