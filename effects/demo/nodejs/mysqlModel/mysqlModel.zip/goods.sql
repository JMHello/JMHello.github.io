/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 60011
Source Host           : localhost:3306
Source Database       : goods

Target Server Type    : MYSQL
Target Server Version : 60011
File Encoding         : 65001

Date: 2017-12-21 14:55:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for list
-- ----------------------------
DROP TABLE IF EXISTS `list`;
CREATE TABLE `list` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isNew` tinyint(1) unsigned zerofill DEFAULT NULL,
  `commend` tinyint(1) unsigned zerofill DEFAULT NULL,
  `discount` tinyint(1) unsigned zerofill DEFAULT NULL,
  `stock` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  CONSTRAINT `list_ibfk_1` FOREIGN KEY (`type`) REFERENCES `type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of list
-- ----------------------------
INSERT INTO `list` VALUES ('2', '橘子', '22', '6', '信必果鲜橙江西赣州赣南脐橙净重10斤装手剥橙新鲜水果寻乌甜橙子', '1', '1', '1', '40');
INSERT INTO `list` VALUES ('3', '番石榴', '22', '6', '广西现摘番石榴芭乐6斤装 新鲜热带水果 高山种植老树 清脆香甜', '1', '1', '1', '40');
INSERT INTO `list` VALUES ('4', 'Edifier/漫步者', '149', '1', 'Edifier/漫步者 R101V笔记本电脑音响家用台式迷你小音箱重低音炮', '0', '1', '0', '40');
INSERT INTO `list` VALUES ('5', 'Amoi/夏新', '180', '1', 'Amoi/夏新 K2无线蓝牙插卡音箱车载低音小钢炮手机迷你电脑音响', '0', '1', '1', '40');
INSERT INTO `list` VALUES ('6', '养乐多', '11', '2', '养乐多活菌型乳酸菌乳饮品100ml*5酸奶 食品饮料', '0', '1', '1', '10');
INSERT INTO `list` VALUES ('7', '板鞋', '88', '3', '花花公子板鞋男运动休闲鞋加绒男鞋保暖棉鞋子男韩版潮流冬季潮鞋', '0', '1', '1', '100');
INSERT INTO `list` VALUES ('8', '4册二年级米小圈上学记', '33', '4', '4册二年级米小圈上学记第二辑正版包邮全套小学生课外阅读书籍儿童畅销文学故事书注音版二年级课外书必读童书7-10岁童话2年级读物', '1', '1', '0', '10');
INSERT INTO `list` VALUES ('9', '玫瑰', '108', '5', '鲜花礼盒全国速递红玫瑰北京同城鲜花上海送花南京广州鲜花店杭州', '1', '1', '0', '12');
INSERT INTO `list` VALUES ('10', '益力多', '12', '2', '好好喝的益力多', '1', '1', '0', '90');
INSERT INTO `list` VALUES ('11', '益力多2', '12', '2', '好好喝的益力多', '1', '1', '0', '90');
INSERT INTO `list` VALUES ('12', '益力多3', '12', '2', '好好喝的益力多', '1', '1', '0', '90');
INSERT INTO `list` VALUES ('13', '草莓', null, null, null, null, null, null, null);
INSERT INTO `list` VALUES ('14', '芒果', null, null, null, null, null, null, null);
INSERT INTO `list` VALUES ('15', '芒果', null, null, null, null, null, null, null);
INSERT INTO `list` VALUES ('16', '芒果', null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e');

-- ----------------------------
-- Table structure for type
-- ----------------------------
DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of type
-- ----------------------------
INSERT INTO `type` VALUES ('1', '音响');
INSERT INTO `type` VALUES ('2', '饮品');
INSERT INTO `type` VALUES ('3', '鞋子');
INSERT INTO `type` VALUES ('4', '书本');
INSERT INTO `type` VALUES ('5', '鲜花');
INSERT INTO `type` VALUES ('6', '水果');
INSERT INTO `type` VALUES ('7', '可爱的宠物');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'jm', 'e10adc3949ba59abbe56e057f20f883e', '佛山', '15626168867', '471938302@qq.com', '1');
