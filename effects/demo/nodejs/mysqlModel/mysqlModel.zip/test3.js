/**
 * 1. 数据处理
 */
const mysql = require('mysql')

const options = {
  host: 'localhost',
  port: 3306,
  database: 'goods',
  user: 'root',
  password: 'sz1997'
}

let connection = mysql.createConnection(options);

// 建立连接
let connect = function () {
  return new Promise((resolve, reject) => {
    connection.connect((err) => {
      if (err) {
        reject(err)
      } else {
        resolve()
      }
    })
  })
}

// 关闭连接
let end = function () {
  return new Promise((resolve, reject) => {
    connection.end((err) => {
      if (err) {
        reject(err)
      } else {
        resolve()
      }
    })
  })
}

// 数据处理
let query = function (sql, parameters) {
  return new Promise((resolve, reject) => {
    connection.query(sql, parameters, (err, results) => {
      if (err) {
        reject(err)
      } else {
        resolve(results)
      }
    })
  })
}

// 测试
connect().
  then(() => {
  console.log('连接数据库成功！')
  return query(`SELECT * FROM list WHERE id=1`)
})
  .then((results) => {
  console.log(results)
  return end()
  })
  .then(() => {
  console.log('关闭数据库成功！')
})

