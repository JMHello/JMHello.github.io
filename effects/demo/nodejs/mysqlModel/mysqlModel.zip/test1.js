/**
 * 1. 主要查看connection对象，看看其有什么属性
 * 2. 建立数据库连接
 * 3. 关闭数据库连接
 */
const mysql = require('mysql')

const options = {
  host: 'localhost',
  port: 3306,
  database: 'goods',
  user: 'root',
  password: 'sz1997'
}

let connection = mysql.createConnection(options);

// 输出 connection 对象
console.log(connection);

// 连接数据库
connection.connect(function (err) {
  if (err) {
    console.log('连接数据库失败！')
  } else {
    console.log('连接数据库成功！')
  }
})

// 关闭数据库
connection.end(function (err) {
  if (err) {
    console.log('关闭数据库失败！')
  } else {
    console.log('关闭数据库成功！')
  }
})

