1、先安装 npm i

2、有进行静态资源管理：

命令行输入 node app2.js 

打开网址：http://localhost:3001/index,html

3、没有进行静态资源管理：

命令行输入 node app1.js 

打开网址：http://localhost:3000/index,html