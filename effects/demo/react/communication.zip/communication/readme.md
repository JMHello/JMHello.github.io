> * npm i 下载包
> * npm run dev 打开页面