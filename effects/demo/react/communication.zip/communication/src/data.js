module.exports = [
  '苹果',
  '雪梨',
  '桃子',
  '梨子'
]