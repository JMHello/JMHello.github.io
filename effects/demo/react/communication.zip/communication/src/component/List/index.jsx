import React, {Component} from 'react'
import ListItem from '../ListItem/index'

import data from './../../data'

import './style.css'

class List extends Component {
  constructor (props) {
    super(props)
  }
  render () {
    const keyword = this.props.keyword
    const filterResult = data.filter((item) => {
      return item.includes(keyword)
    })
    return (
      <ul className="search-list">
        {
          filterResult.map((item, i) => {
            return <ListItem data={item} key={i}/>
          })
        }
      </ul>
    )
  }
}

module.exports = List