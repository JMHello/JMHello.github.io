import React, {Component} from 'react'
import './style.css'

class Input extends Component {
  constructor (props) {
    super(props)
  }
  handleKeyUp (e) {
    const value = e.target.value
    this.props.onChange(value)
  }
  render () {
    return (
      <input type="text" className="search-input" onKeyUp={this.handleKeyUp.bind(this)}/>
    )
  }
}

module.exports = Input