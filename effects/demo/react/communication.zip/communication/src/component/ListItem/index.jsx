import React, {Component} from 'react'

import './style.css'

class ListItem extends Component {
  constructor (props) {
    super(props)
  }
  render () {
    return (
      <li className="list-item">{this.props.data}</li>
    )
  }
}

module.exports = ListItem