import React, {Component} from 'react'
import ReactDOM from 'react-dom'
import Input from '../component/Input/index'
import List from '../component/List/index'

import './style.css'

class App extends Component {
  constructor (props) {
    super(props)
    this.state = {
      keyword: ''
    }
  }

  onChange (value) {
   this.setState({
     keyword: value
   })
  }

  render () {
    return (
      <div className="search-wrapper">
        <Input onChange={this.onChange.bind(this)}/>
        <List keyword={this.state.keyword}/>
      </div>
    )
  }
}

ReactDOM.render(
  <App/>,
  document.getElementById('root')
)