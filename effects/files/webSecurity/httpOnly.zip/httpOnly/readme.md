1. npm install 下载一些依赖的包
2. 在命令行输入这行代码 node app.js 
3. 在浏览输入地址 http://localhost:8080/
4. 用户列表可查看 model/user.js 里的 Users数组