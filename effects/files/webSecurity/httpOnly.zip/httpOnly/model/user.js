/**
 * 用户列表
 * @type {[null,null,null]}
 */
const Users = [{
  username: 'jm',
  age: 20,
  password: '123456'
},{
  username: 'aa',
  age: 21,
  password: '123456'
},{
  username: 'bb',
  age: 22,
  password: '123456'
}];

// 存储用户信息
let userSession = {};

const UserModel = {
  /**
   * 判断是否存在这个用户
   * @param {String} userName 用户名
   * @param password 密码
   * @returns {boolean}
   */
  isUser: (userName, password) => {
    for (let index = 0, len = Users.length; index < len; index++) {
      const item = Users[index];
      if (item.username === userName && item.password === password) {
        return true;
      }
    }
    return false;
  },
  /**
   * 设置用户的cookie
   * @param {username} username 用户名
   * @param {Object} res http.ServerResponse对象
   */
  setUserCookie: (username, res) => {
    // 简单的计算获得用户的登陆态 cookie
    const userKey = 'userkey_' + Math.random() * 1000;

    // 设置 Cookie

    // 没有设置 httpOnly
    // res.setHeader('Set-Cookie', [`userkey=${userKey}`, `username=${username}`])

    // 设置 httpOnly
    res.setHeader('Set-Cookie', [`userkey=${userKey}; httpOnly`, `username=${username}; httpOnly`])

    // 存用户登陆态 cookie
    userSession[username] = userKey;
  }
}
module.exports = UserModel;