/*
* 思路
* 1. 用户第一次登陆，就会将用户名和密码发给后台，
*    服务器接收到发来的数据后，会与数据库里的数据作比较，如果是完全等价的，就会返回标识 ===》 用户名 + 随机生成的数据 给客户端。
* 2、客户端接收到服务器返回的数据后，可以在回调函数里将这返回的数据设置为cookie。（我们可以将返回的数据看作用户的标识）
* 3、 下一次用户如果登录的话（在cookie还没有被注销前）,将保存的cookie里面的 那个标识 也发给后端，那么服务器就会通过这个标识返回对应的数据
*     给客户端。
* -----------------------------------------------------------------------------------------------
*  res.setHeader('Set-Cookie', [`userkey=${userKey}`, `username=${username}`]) ===> 浏览器就会自动设置 `session` cookie
*  但前提是，必须是同域而不能跨域
* -----------------------------------------------------------------------------------------------
* 不用express，静态文件的路径配置不会
* */

const user = require('./model/user.js');
const http = require('http');
const fs = require('fs');

const server = http.createServer();

server.on('request', (req, res) => {
  let url = req.url;

  // 根目录 --- 登录页面
  if (url === '/') {
    const data = fs.readFileSync('./public/index.html', 'utf-8');
    res.writeHead(200, {
      'Content-Type': 'text/html',
    })
    res.write(data);
    res.end();

  } else if (url === '/login') { // 登录

    req.on('data', (data) => {
      let reqData = JSON.parse(data);

      if (user.isUser(reqData.username, reqData.password)) {
        user.setUserCookie(reqData.username, res);
        res.write(JSON.stringify({
          status: true
        }))

      } else {

        res.writeHead(404, {
          'Content-Type': 'text/plain; charset=utf8',
        })

        res.write(JSON.stringify({
          status: false,
          reason: '用户名不存在或者密码错误！'
        }));
      }

      res.end();
    })
  }
});


server.listen(8080, 'localhost');




