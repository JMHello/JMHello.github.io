const http = require('http');
const fs = require('fs');
const user = require('./model/user.js');
const bank = require('./model/bank.js');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;
  if (url === '/') { // 登录页面
    const data = fs.readFileSync('./public/bank-fish.html', 'utf-8');
    res.writeHead(200, {
      'Content-Type': 'text/html',
    })
    res.write(data);
    res.end();
  } else if (url === '/bank-transfer.html') {
    const data = fs.readFileSync('./public/bank-transfer.html', 'utf-8');
    res.writeHead(200, {
      'Content-Type': 'text/html',
    })
    res.write(data);
    res.end();
  }
});

server.listen(3001, 'localhost');