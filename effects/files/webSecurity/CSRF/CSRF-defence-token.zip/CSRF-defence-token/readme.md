1. 下载一些依赖的包 npm install 

2. 正常转账
* 只需要运行node app.js  
    * 先打开 http://localhost:8080/login 登录页面
    * 登录之后就可以测试了
* 注意，正常转账需要在两个不同浏览器中才能测试到，因为同一个浏览器的cookie会覆盖！！

3. 转账攻击
* 需要运行 node app.js 
*  需要运行 node evil.js
    * 伪造添加评论的请求
    
    
