const http = require('http');
const fs = require('fs');
const user = require('./model/user.js');
const bank = require('./model/bank.js');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;
  if (url === '/login') { // 登录页面
    const data = fs.readFileSync('./public/index.html', 'utf-8');
    res.writeHead(200, {
      'Content-Type': 'text/html',
    })
    res.write(data);
    res.end();
  } else if (url === '/login_action') { // 登录接口
    req.on('data', (data) => {
      let reqData = JSON.parse(data);

      if (user.isUser(reqData.username, reqData.password)) {
        user.setUserCookie(reqData.username, res);
        res.write(JSON.stringify({
          status: true
        }))
      } else {
        res.writeHead(200, {
          'Content-Type': 'text/plain; charset=utf8',
        })

        res.write(JSON.stringify({
          status: false,
          reason: '用户名不存在或者密码错误！'
        }));
      }

      res.end();
    })
  } else if (url === '/bank.html') {
    const data = fs.readFileSync('./public/bank.html', 'utf-8');
    res.writeHead(200, {
      'Content-Type': 'text/html',
    })
    res.write(data);
    res.end();
  } else if(url === '/get_user_money') {
    if (user.checkUserByCookie(req)) {
      const username = user.getUserDetail(req).username;
      const money = bank.getUserMoney(username);

      res.write(JSON.stringify({
        status: true,
        data: {
          username: username,
          money: money
        }
      }))

      res.end();
    }

  } else if( url === '/transfer_money') {
    bank.transferMoney(req, res);
  }
});

server.listen(8080, 'localhost');