const user = require('./user');

/**
* 银行数据模块
*/


// 用户对应的账户的金额
let banks = {
  'jm': 10000,
  'badboy': 100,
  'garven': 4000
};

const BankModel = {
  transferMoney: (req, res) => {
    req.on('data', function (data) {
      const result = JSON.parse(data);

      // 转账的用户存在才可以转账
      if (banks[result.account]) {

        // token 验证
        if(user.getUserToken(result.username) === result.token){
          if (banks[result.username] - result.money > 0) {
            banks[result.username] = parseInt( banks[result.username]) - parseInt(result.money);
            banks[result.account] = parseInt(banks[result.account]) + parseInt(result.money);
            res.write(JSON.stringify({
              status: true
            }));
          } else {
            res.write(JSON.stringify({
              status: false,
              info: '余额不足'
            }));
          }
        } else {
          res.writeHead(200, {
            'Content-Type': 'text/plain; charset=utf8'
          })
          res.write(JSON.stringify({
            status: false,
            info: 'token校验失败'
          }))
        }
      } else {
        res.write(JSON.stringify({
          status: false,
          info: '转账失败，该用户不存在'
        }));
      }
      res.end();
    })
  },
  getUserMoney: (userName) => {
    return banks[userName] || 0;
  }
}

module.exports = BankModel;
