const http = require('http');

const content = JSON.stringify({
  content: '<a href="#">test3</a>'
});

const opts = {
  host: 'localhost',
  port: '8080',
  path: '/addCommentData_action',
  method: 'POST',
  headers: {
    'Cookie': 'userkey=userkey_268.3329513853596; username=jm', // 每一登录，都需要更换这个值才能伪造 post 请求成功
    'Content-Length': content.length
  }
}

// 伪造 post 请求
const req = http.request(opts, function(res){
  res.setEncoding('utf8');
  res.on('data',function(data){
    console.log("data:",data);   //一段html代码
  });
});

req.write(content);
req.end();