/**
 * 用户列表
 * @type {[null,null,null]}
 */
const Users = [{
  username: 'jm',
  age: 20,
  password: '123456'
},{
  username: 'badboy',
  age: 21,
  password: '123456'
},{
  username: 'garven',
  age: 22,
  password: '123456'
}];

// 存储用户信息
let userSession = {};

const UserModel = {
  /**
   * 判断是否存在这个用户
   * @param {String} userName 用户名
   * @param password 密码
   * @returns {boolean}
   */
  isUser: (userName, password) => {
    for (let index = 0, len = Users.length; index < len; index++) {
      const item = Users[index];
      if (item.username === userName && item.password === password) {
        return true;
      }
    }
    return false;
  },
  /**
   * 设置用户的cookie
   * @param {username} username 用户名
   * @param {Object} res http.ServerResponse对象
   */
  setUserCookie: (username, res) => {
    // 简单的计算获得用户的登陆态 cookie
    const userKey = 'userkey_' + Math.random() * 1000;

    // 设置 Cookie
    res.setHeader('Set-Cookie', [`userkey=${userKey}`, `username=${username}`])

    // 存用户登陆态 cookie
    userSession[username] = userKey;
  },
  /**
   * 检查用户的cookie信息
   * @param {Object} req http.IncomingMessage对象
   * @returns {boolean}
   */
  checkUserByCookie: (req) => {
    const cookie = req.headers.cookie;
    const userkey = getCookie(cookie, 'userkey');
    const username = getCookie(cookie, 'username');

    if (userSession[username] && userSession[username] === userkey) {
      return true;
    }
    return false;
  },
  /**
   * 根据cooke获取对应的用户信息
   * @param {Object} req http.IncomingMessage对象
   * @returns {Object|null}
   */
  getUserDetail: (req) => {
    const cookie = req.headers.cookie;
    const username = getCookie(cookie, 'username');

    for (let item of Users) {
      if(item.username === username) {
        return item;
      }
    }
    return null;
  }
}

/**
 * 获取cookie值
 * @param {String} cookie cookie
 * @param {String} cookieName cookie的名字
 * @returns {String|null}
 */
function getCookie (cookie, cookieName) {
  if(typeof cookie === 'string') {
    const reg = new RegExp('(?:^|\\s)' + cookieName + '=(.+?(?=;|$))');
    const result = cookie.match(reg);
    return result? result[1]: null;
  }
  return null;
}

module.exports = UserModel;