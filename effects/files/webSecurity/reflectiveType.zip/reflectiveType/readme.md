1. 安装包：npm i
2. 运行：node app.js
3. 可以在浏览器输入：
   * 以下url都是有数据的：
      * http://localhost:8080/goods.html?type=book
      * http://localhost:8080/goods.html?type=flower
      * http://localhost:8080/goods.html?type=food
   * “特别url”：
      *  http://localhost:8080/goods.html?type=<script>console.log(window)</script>  --- 表现：在控制台输出window对象 
      *  http://localhost:8080/goods.html?type=<script>alert(1)</script> --- 表现：有提示框弹出，内容为1

* 补充
   * “特别url”的话，我在chrome和FireFox测试过，这两个浏览器都有 XSS 的防护，而在 ie 测试过，没有 XSS 防护，就会有上述的表现。
   * 或许浏览器的版本不一样，所表现出来的也不一样，大家要试一试才知道哟！！