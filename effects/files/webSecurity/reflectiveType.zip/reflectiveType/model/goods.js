// 数据列表
const GoodsData = {
  book: {
    name: '书本',
    data: [
      {
        name: '十万个为什么',
        author: 'aaa'
      },
      {
        name: 'javascript',
        author: 'bbb'
      }
    ]
  },
  food: {
    name: '食物',
    data: [
      {
        name: '面包',
        price: '5'
      },
      {
        name: '苹果',
        price: '5'
      },
      {
        name: '樱桃',
        price: '5'
      }
    ]
  },
  flower: {
    name: '花朵',
    data: [
      {
        name: '水仙花'
      },
      {
        name: '玫瑰花'
      },
      {
        name: '菊花'
      }
    ]
  }
};

const GoodsModule = {
  /**
   * 获取url中type的值
   * @param url
   * @returns {*}
   */
  getType: function (url) {
    const reg = new RegExp('(?:\\?|&)type=(.*?(?=&|$))')
    const mResult = url.match(reg);

    if(mResult) {
      console.log(mResult[1]);
      return mResult[1];
    }

    return null;
  },
  /**
   * 根据type对应的数据
   * @param type
   * @returns {*}
   */
  getData: function (type) {
   if (type in GoodsData) {
      return GoodsData[type];
   }
   return null;
  },
  /**
   * 展示数据
   * @param data
   * @returns {string}
   */
  showData: function (data) {
    let str = '';
    for (let item of data) {
      str += `<li>名字：${item.name}</li>`;
    }
    return str;
  }
};


module.exports = GoodsModule;