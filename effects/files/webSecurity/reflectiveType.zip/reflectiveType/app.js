const http = require('http');

const goods = require('./model/goods');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;

  if (url.includes('/goods.html')) {
    const type = goods.getType(url);
    const data = goods.getData(type);
    let str = '';

    if (data) {
      str = `<html>
            <head>
            <title>反射型 XSS</title>
            <meta charset="utf-8">
            </head>
            <body>
            <p>当前分类：${data.name}</p>
            <ul>
                ${goods.showData(data.data)}
            </ul>
            </body>
            </html>`;
    } else {
      str = `<html>
             <head>
            <title>反射型 XSS</title>
            <meta charset="utf-8">
            </head>
            <body>
            <p>当前分类：${type}</p>   
            <p>没有该类型商品。</p>
            </body>
            </html>`;
    }

    res.writeHead(200, {
      'Content-Type': 'text/html'
    })

    res.write(str);
    res.end();
  }
});

server.listen(8080, 'localhost');