1. 下载一些依赖的包 npm install 
2. 在命令行输入这行代码 node app.js 
3. 在浏览输入地址 http://localhost:8080/comment.html
4. 输入评论，新的评论会自动增加