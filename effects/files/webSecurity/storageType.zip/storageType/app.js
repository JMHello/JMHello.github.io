const http = require('http');
const fs = require('fs');
const comment = require('./model/comment');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;
  if (url === '/comment.html') {
    const data = fs.readFileSync('./public/index.html');
    res.write(data);
    res.end();
  } else if (url === '/getCommentData_action') { // 获取评论
    const data = comment.getData();
    res.write(JSON.stringify({
      status: true,
      data: data
    }));
    res.end();
  } else if (url === '/addCommentData_action') { // 添加评论
    comment.addData(req);
    res.write(JSON.stringify({
      status: true
    }))
    res.end();
  }
});

server.listen(8080, 'localhost');