let CommentsData = [
  {
    name: '用户1',
    content: 'hello lallala'
  },
  {
    name: '用户2',
    content: 'hello lallala'
  },
  {
    name: '用户3',
    content: 'hello lallala'
  },
  {
    name: '用户4',
    content: '<a href="http://localhost:3001/fish.html">王者荣耀</a>'
  }
];

const CommentModule = {
  getData: function () {
    return CommentsData;
  },
  addData: function (req) {
    const len = CommentsData.length;

    req.on('data', function (data) {
      const result = JSON.parse(data);
      CommentsData.push({
        name: `用户${len}`,
        content: result.content
      })
    });

  }
};

module.exports = CommentModule;