1. 下载一些依赖的包 npm install 
2. 在命令行输入这行代码
     node app.js ===》 http://localhost:8080/comment.html 是评论网站，点击打开“王者荣耀”这个链接，就会打开一个网站
     node app2.js ====》 http://localhost:3001/fish.html 是钓鱼网站，当你填入 qq 号码和 qq 密码的时候，并且登录后，这些信息就会被窃取。
                         http://localhost:3001/user.html 展现刚刚窃取回来的信息
