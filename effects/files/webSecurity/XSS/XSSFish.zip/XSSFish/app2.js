const http = require('http');
const fs = require('fs');
const fish = require('./model/fish');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;
  if (url === '/fish.html') {
    const data = fs.readFileSync('./public/fish.html');
    res.write(data);
    res.end();
  } else if (url === '/login_action') { // 存储登录信息
    fish.addData(req, res);
  } else if (url === '/user.html') { // 获取登录信息
    res.write(JSON.stringify({
      status: true,
      data: fish.getData()
    }))
    res.end();
  }
});

server.listen(3001, 'localhost');