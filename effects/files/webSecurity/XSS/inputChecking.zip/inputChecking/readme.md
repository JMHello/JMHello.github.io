1. 下载一些依赖的包 npm install 
2. 在命令行输入这行代码

* node app.js  
    * 先打开 http://localhost:8080/login 登录页面
    * 登录之后就可以测试了

* node request.js
    * 伪造添加评论的请求
    
    
--- 

输入的内容：

<a href="ke.qq.com">XSS</a>
