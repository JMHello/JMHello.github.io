let CommentsData = [
  {
    name: '用户1',
    content: 'hello lallala'
  },
  {
    name: '用户2',
    content: 'hello lallala'
  },
  {
    name: '用户3',
    content: 'hello lallala'
  },
  {
    name: '用户4',
    content: '<a href="http://localhost:3001/fish.html">王者荣耀</a>'
  }
];

const CommentModule = {
  getData: function () {
    return CommentsData;
  },
  addData: function (req) {
    const cookie = req.headers.cookie;
    const username = getCookie(cookie, 'username');
    req.on('data', function (data) {
      const result = JSON.parse(data);
      CommentsData.push({
        name: username,
        // 未转义
        content: result.content
        // 转义
        // content: htmlEncode(result.content)
      })
    });
  }
};

/**
 * 获取cookie值
 * @param {String} cookie cookie
 * @param {String} cookieName cookie的名字
 * @returns {String|null}
 */
function getCookie (cookie, cookieName) {
  const reg = new RegExp('(?:$|\\s)' + cookieName + '=(.+?(?=;|$))');
  const result = cookie.match(reg);
  return result? result[1]: null;
}

/**
 * htmlEncode
 * @param {String} str 需转义的字符串
 */
function htmlEncode (str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

module.exports = CommentModule;