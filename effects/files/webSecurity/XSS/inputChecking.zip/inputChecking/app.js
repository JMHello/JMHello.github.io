const http = require('http');
const fs = require('fs');
const comment = require('./model/comment');
const user = require('./model/user.js');

const server = http.createServer();

server.on('request', function (req, res) {
  const url = req.url;
  if (url === '/login') { // 登录页面
    const data = fs.readFileSync('./public/index.html', 'utf-8');
    res.writeHead(200, {
      'Content-Type': 'text/html',
    })
    res.write(data);
    res.end();

  } else if (url === '/login_action') { // 登录接口

    req.on('data', (data) => {
      let reqData = JSON.parse(data);

      if (user.isUser(reqData.username, reqData.password)) {
        user.setUserCookie(reqData.username, res);
        res.write(JSON.stringify({
          status: true
        }))
      } else {
        res.writeHead(404, {
          'Content-Type': 'text/plain; charset=utf8',
        })

        res.write(JSON.stringify({
          status: false,
          reason: '用户名不存在或者密码错误！'
        }));
      }

      res.end();
    })
  } else if (url.includes('/comment.html')) {
   if(user.checkUserByCookie(req)){
     const data = fs.readFileSync('./public/comment.html');
     res.write(data);
     res.end();
   } else {
     res.write(`用户不存在，无法读取页面`);
     res.end();
   }
  } else if (url === '/getCommentData_action') { // 获取评论
    const data = comment.getData();
    res.write(JSON.stringify({
      status: true,
      data: data
    }));
    res.end();
  } else if (url === '/addCommentData_action') { // 添加评论
    comment.addData(req);
    res.write(JSON.stringify({
      status: true
    }))
    res.end();
  }
});

server.listen(8080, 'localhost');